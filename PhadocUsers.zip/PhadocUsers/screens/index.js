import Home from "./Home"
import Profil from "./Profil"
import SignUp from "./SignUp"
import Register from "./Register"
import ListePatients from "./ListePatients"
import Accueil from "./Accueil"
import DetailPatients from "./DetailPatients"
import Parametre from "./Parametre"
import Laboratoire from "./Laboratoire"
import Clinique from "./Clinique"
import Pharmacie from "./Pharmacie"
import Urgence from "./Urgence"

export {
    Home,
    Profil,
    Laboratoire,
    Clinique,
    Pharmacie,
    Urgence,
    DetailPatients,
    Parametre,
    ListePatients,
    Accueil,
    SignUp,
    Register
};
