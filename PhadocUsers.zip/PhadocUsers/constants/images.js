const wallieLogo = require("../assets/images/wallie-logo.png");
const banner = require("../assets/images/banner.png");
const promoBanner = require("../assets/images/promo-banner.png");
const focus = require("../assets/images/focus.png");
const logo = require("../assets/images/logo.png");
const docteur = require("../assets/images/docteur.png");
const profile = require ("../assets/images/profile.jpg");
const bannermedecin = require ("../assets/images/bannermedecin.jpg");
const profilDoc = require ("../assets/images/profilDoc.jpg");
const urgence = require ("../assets/images/urgence.jpg")
const clinique = require ("../assets/images/clinique.jpg")
const laboratoire = require ("../assets/images/laboratoire.jpg")
const pharmacie = require ("../assets/images/pharmacie.jpg")


// Dummy



export default {
    wallieLogo,
    banner,
    urgence,
    pharmacie,
    laboratoire,
    clinique,
    profilDoc,
    docteur,
    bannermedecin,
    profile,
    logo,
    promoBanner,
    focus,

   
}