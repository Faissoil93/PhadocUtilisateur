const back = require("../assets/icons/back.png");
const bell = require("../assets/icons/bell.png");
const bill = require("../assets/icons/bill.png");
const close = require("../assets/icons/close.png");
const disable_eye = require("../assets/icons/disable_eye.png");
const down = require("../assets/icons/down.png");
const eye = require("../assets/icons/eye.png")
const game = require("../assets/icons/games.png");
const barcode = require("../assets/icons/barcode.png");
const info = require("../assets/icons/info.png");
const internet = require("../assets/icons/internet.png");
const more = require("../assets/icons/more.png");
const phone = require("../assets/icons/phone.png");
const reload = require("../assets/icons/reload.png");
const scan = require("../assets/icons/scan.png");
const send = require("../assets/icons/send.png");
const user = require("../assets/icons/user.png");
const wallet = require("../assets/icons/wallet.png");
const liste = require("../assets/icons/liste.png");
const parametres = require("../assets/icons/parametres.png");
const logo = require("../assets/icons/logo.png");
const Profil = require("../assets/icons/Profil.png");
const x = require("../assets/icons/x.png");
const success = require("../assets/icons/success.png");
const urgence = require("../assets/icons/urgence.png");
const laboratoire = require("../assets/icons/laboratoire.png");
const pharmacie = require("../assets/icons/pharmacie.png");
const clinique = require("../assets/icons/clinique.png");
const medecin = require("../assets/icons/medecin.png");

export default {
    back,
    bell,
    laboratoire,
    pharmacie,
    clinique,
    medecin,
    bill,
    urgence,
    success,
    x,
    liste,
    Profil,
    logo,
    parametres,
    close,
    disable_eye,
    down,
    eye,
    game,
    barcode,
    info,
    internet,
    more,
    phone,
    reload,
    scan,
    send,
    user,
    wallet
}