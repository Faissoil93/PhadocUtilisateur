

import React from 'react';

import { SignUp, Register,ListePatients,Accueil,DetailPatients,Parametre, Profil,Clinique, Pharmacie, Urgence,Laboratoire } from "./screens";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import Tabs from "./navigation/tabs";



const theme = {
    ...DefaultTheme,
    colors: {
        ...DefaultTheme.colors,
        border: "transparent",
    },
};

const Stack = createStackNavigator();

const App = () => {
    const [loaded] = useFonts({
        "Roboto-Black" : require('./assets/fonts/Roboto-Black.ttf'),
        "Roboto-Bold" : require('./assets/fonts/Roboto-Bold.ttf'),
        "Roboto-Regular" : require('./assets/fonts/Roboto-Regular.ttf'),
    })
    
    if(!loaded){
    return null;
    }
    return (
        <NavigationContainer theme={theme}>
            <Stack.Navigator
                screenOptions={{
                    headerShown: false
                }}
                initialRouteName={'SignUp'}
            >
                <Stack.Screen name="SignUp" component={SignUp} />
                <Stack.Screen name="Register" component={Register} />
                <Stack.Screen name="ListePatients" component={ListePatients} />
                <Stack.Screen name="Accueil" component={Accueil} />
                <Stack.Screen name="DetailPatients" component={DetailPatients} />
                <Stack.Screen name="Parametre" component={Parametre} />
                <Stack.Screen name="Laboratoire" component={Laboratoire} />
                <Stack.Screen name="Clinique" component={Clinique} />
                <Stack.Screen name="Pharmacie" component={Pharmacie} />
                <Stack.Screen name="Urgence" component={Urgence} />
                 


                {/* Tabs */}
                <Stack.Screen name="Home" component={Tabs} />
                <Stack.Screen name="Profil" component={Profil} />

            </Stack.Navigator>
        </NavigationContainer>
    )
}

export default App;
